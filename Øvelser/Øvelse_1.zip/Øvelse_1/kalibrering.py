import matplotlib.pyplot as plt
import numpy as np
import scipy.optimize as scp

# fig, ax = plt.subplots()

# Plot data

x = []
y = []

del_x = 4.5*10**-2

for i in list(range(12)):
    x = x + [i*del_x]
    y = y +  [np.mean(np.loadtxt('Kalibrering/'+str(i)+'_måling.txt')[:,1])]

# ax.scatter(x,y, color = 'r', label = 'data point')

# Plot fit

def func(x,a,b):
    return a*x+b

guess_params = [0,1]
popt,pcov = scp.curve_fit(func,x,y,guess_params)

# x_fit = np.linspace(0,x[-1],100)
# ax.plot(x_fit, func(x_fit, popt[0], popt[1]), color = 'k', label = 'fit')

# ax.set_xlabel('x')
# ax.set_ylabel('U')
# ax.set_ylim(0,1.2)
# ax.legend()

#plt.show()

#fig.savefig('spænding.png')

def Convert_U(U):
    return (U/popt[0])
