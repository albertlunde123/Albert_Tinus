import matplotlib.pyplot as plt
import numpy as np
import scipy.optimize as scp

exec(open('kalibrering.py').read())

# Vi har nu adgang til funktion Convert_U(U), som er defineret i
# kalibrering.py.

fig, ax = plt.subplots()

U = np.loadtxt('Rulle/cyl_1.txt')[:,1]
t_unadjusted = np.loadtxt('Rulle/cyl_1.txt')[:,0]

x_unad = Convert_U(U)-Convert_U(U)[0]
x = x_unad
t = (t_unadjusted-t_unadjusted[0])/(1000)

ax.scatter(t[0:700],x[0:700], color = 'red', label = 'data points')

# plot fit

def func(t,a):
    return a*t**2

guess_params = [1]
popt,pcov = scp.curve_fit(func,t[:700],x[:700],guess_params)

t_fit = np.linspace(0,0.7,1000)
ax.plot(t_fit, func(t_fit, popt[0]), color = 'k', linewidth = 3,
        label = 'fitted function')

ax.set_ylim(0,0.6)
ax.set_ylabel('x/m')
ax.set_xlabel('t/s')
ax.legend()
plt.show()

###############

grader = 17
theta = grader*(2*np.pi/360)

a_teoretisk = np.sin(theta)*9.82*2/3
a = popt[0]

print(a)
print(a_teoretisk)
print(pcov)

fig.savefig('ruller.png')

